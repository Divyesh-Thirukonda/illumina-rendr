Running instructions:
$ g++ raycaster.cpp -o raytracer1d
$ ./raytracer1d showcase.txt


I allowed the user to add a BVH with the following syntax:
bvh axis direction threshold

example:
bvh 0 5 -100 100 -100 100
The example above means that only parts of the object where 0 < x < 5 will allow reflections and refractions.
For all x > 5 and x < 0, we skip the reflections and refractions step.
We ignore the y and z in this example because they are so big
If you don't include a bvh, it will by default render from -10000 to 10000

The main implementation for this is in where we search for all shapes to reflect / refract off of.
double t_clos = numeric_limits<double>::max();
for (const auto& _sphere : scene.spheres) {
    double t_s;
    if (raySphereIntersect(refractionRay, _sphere, t_s) && t_s > 0 && t_s < t_clos) {
        t_clos = t_s;
        // BVH (EC)
        // if intersectionPoint in rect bounds
        if (intersectionPoint.x < scene.bvh[0].y && intersectionPoint.x > scene.bvh[0].x && intersectionPoint.y < scene.bvh[1].y && intersectionPoint.y > scene.bvh[1].x && intersectionPoint.z < scene.bvh[2].y && intersectionPoint.z > scene.bvh[2].x) {
            // and t moves past rect bounds
            Vec3 hitPoint = intersectionPoint + T*t_s;
            if (hitPoint.x < scene.bvh[0].y && hitPoint.x > scene.bvh[0].x && hitPoint.y < scene.bvh[1].y && hitPoint.y > scene.bvh[1].x && hitPoint.z < scene.bvh[2].y && hitPoint.z > scene.bvh[2].x) {
                refractionColor = shadeRaySphere(scene, refractionRay, _sphere, t_s, countBounces + 1);
            }
        }
    }
}

In showcase5.txt, only reflections from x coordinate 0 to 3 are visible. We can no longer see the reflection of the FULL ball on the floor.


2b: I allowed the refractive material to have color by assigning the alpha an RGB value.
This is the syntax:
mtlcolorplus 0.2 0.2 0.2  1.0 1.0 1.0  0.0 0.9 1.0  50  .1 0 0  0.5
                                                        ^^^^^^
                                                        These values are the filter of the RGB values, so enabling the red flag slightly will give a cyan hue
Additionally, the alpha value is set to the average value of these 3 values

This is the main code for this:
if (tri.hasAlphaAt) {
    Vec3 alphaAtValRGB = Vec3( pow(2.7183, -tri.alphaR*t), pow(2.7183, -tri.alphaG*t), pow(2.7183, -tri.alphaB*t) );
    float Vr = (1 - F_r) * alphaAtValRGB.x * refractionColor.x;
    float Vg = (1 - F_r) * alphaAtValRGB.y * refractionColor.y;
    float Vb = (1 - F_r) * alphaAtValRGB.z * refractionColor.z;
    Icurr = (Icurr + Vec3(Vr, Vg, Vb));
} else {
    Icurr = (Icurr + refractionColor * (1 - F_r) * (pow(2.7183, -tri.alpha*t)));

    // Or:
    // Icurr = (Icurr + refractionColor * (1 - F_r) * (1 - tri.alpha));
}

See showcase3.txt for an example of it in action, and play around with different alpha wavelenghts and bgColor values.
